package de.liga.dart.ligateam.service;

import de.liga.dart.common.service.ServiceFactory;
import de.liga.dart.common.service.util.HibernateUtil;
import de.liga.dart.exception.DartValidationException;
import de.liga.dart.liga.service.LigaService;
import de.liga.dart.ligaklasse.service.LigaklasseService;
import de.liga.dart.ligateam.model.WunschArt;
import de.liga.dart.model.Liga;
import de.liga.dart.model.Ligaklasse;
import de.liga.dart.model.Ligateam;
import de.liga.dart.model.Spielort;
import de.liga.dart.spielort.service.SpielortService;
import de.liga.util.CalendarUtils;
import junit.framework.TestCase;

import java.util.Calendar;
import java.util.List;

/**
 * Description:   <br/>
 * User: roman
 * Date: 02.11.2007, 13:29:02
 */
public class LigateamServiceTest extends TestCase {
    private LigateamService service;

    public LigateamServiceTest(String string) {
        super(string);
    }

    protected void setUp() throws Exception {
        super.setUp();    // call super!
        service = ServiceFactory.get(LigateamService.class);
    }

    public void testFindWunschListCandidates() {
        ServiceFactory.runAsTransaction(new Runnable() {

            public void run() {
                final Ligateam team1 = createLigaTeam();
                final Ligateam team2 = createLigaTeam();
                team1.addToWuensche(team2, WunschArt.WHITELIST_MUST,
                        HibernateUtil.getCurrentSession());
                HibernateUtil.getCurrentSession().flush();
                List<Ligateam> list =
                        service.findWunschListCandidates(team1, team1.getLiga(), null);
                assertNotNull(list);
                for (Ligateam each : list) {
                    assertEquals(each.getLiga(), team1.getLiga());
                }
            }
        });

    }

    public void testQuery() {
        ServiceFactory.runAsTransaction(new Runnable() {

            public void run() {
                service.findTeamsByLigaKlasseOrt(null, null, null, true);
            }
        });

    }

    public void testLikeQuery() {
        ServiceFactory.runAsTransaction(new Runnable() {

            public void run() {
                List<Ligateam> teams = service.findTeamsLikeNameByLiga("APPY", null);
                // "Happy hippos", etc.
                assertTrue(!teams.isEmpty());
            }
        });
    }

    public void testDeleteAllLigateamWunsch() {
        ServiceFactory.runAsTransaction(new Runnable() {

            public void run() {
                Liga liga = ServiceFactory.get(LigaService.class).findLigaByName("Benden");
                service.deleteAllLigateamWunsch(liga);
            }
        });
    }

    /**
     * jeder aufruf eines Service wird - falls vorher keine
     * Transaction gestartet wurde - als EIGENE Transaction
     * ausgef�hrt.
     */
    public void testCreateTeamAsManyTransactions()
            throws DartValidationException {
        final Ligateam team1 = createLigaTeam();
        final Ligateam team2 = createLigaTeam();
        ServiceFactory.runAsTransaction(new Runnable() {
            public void run() {
                service.saveLigateam(team1);
                service.saveLigateam(team2);
                team1.addToWuensche(team2, WunschArt.WHITELIST_SHALL,
                        HibernateUtil.getCurrentSession());
                assertTrue(team2.findWunsch(team1) != null);
                assertTrue(team2.findWunsch(team2) == null);
                assertTrue(team1.findWunsch(team2) != null);
                assertTrue(team1.findWunsch(team1) == null);
            }
        });
        service.deleteLigateam(team2, false);
        assertTrue(team2.findWunsch(team1) == null);
    }

    /**
     * Das ist besser: alle operationen als 1 Transaktion ausf�hren.
     * Vorteil: Schneller und �nderungen an persistenten Objekten
     * werden AUTOMATISCH gespeichert!
     */
    public void testCreateTeamAsSingleTransaction() {
        ServiceFactory.runAsTransaction(new Runnable() {
            public void run() {
                Ligateam team = createLigaTeam();
                team.setTeamName(team.getTeamName() + "_x");
            }
        });
    }

    private Ligateam createLigaTeam() throws DartValidationException {
        Liga benden =
                ServiceFactory.get(LigaService.class).findLigaByName("Benden");
        assertNotNull(benden);
        List<Ligateam> bendenTeams = service.findAllTeamsInLiga(benden);

        List<Spielort> orte =
                ServiceFactory.get(SpielortService.class).findAllSpielortByLiga(benden);
        Spielort spielort;
        if (orte.isEmpty()) {
            spielort = new Spielort();
            spielort.setAutomatenAnzahl(1);
            spielort.setSpielortName("Willis Kneipe");
            spielort.setLiga(benden);
            ServiceFactory.get(SpielortService.class).saveSpielort(spielort);
        } else {
            spielort = orte.get(0);
        }

        Ligaklasse klasse;
        List<Ligaklasse> klassen =
                ServiceFactory.get(LigaklasseService.class).findAllLigaklasse();
        if (klassen.isEmpty()) {
            klasse = new Ligaklasse();
            klasse.setKlassenName("A");
            klasse.setRang(100);
            ServiceFactory.get(LigaklasseService.class).saveLigaklasse(klasse);
        } else {
            klasse = klassen.get(0);
        }

//        if(bendenTeams.isEmpty()) {
        Ligateam team = new Ligateam();
        team.setLiga(benden);
        team.setTeamName("Benden Tigers" + System.currentTimeMillis());
        team.setSpielort(spielort);
        team.setLigaklasse(klasse);
        team.setWochentag(Calendar.MONDAY);
        team.setSpielzeit(CalendarUtils.createTime(19, 30));
        service.saveLigateam(team);
        System.out.println(
                "Ein Team neu angelegt in Liga " + benden.getLigaName());
        return team;
//        }  else {
//            System.out.println("Die Liga " + benden.getLigaName() + " hat " + bendenTeams.size() + " Teams.");
//            return bendenTeams.get(0);
//        }
    }

}
