package de.liga.dart.gruppen.check;

import de.liga.dart.common.service.ServiceFactory;
import de.liga.dart.gruppen.check.model.OSetting;
import de.liga.dart.gruppen.service.GruppenService;
import de.liga.dart.liga.service.LigaService;
import de.liga.dart.model.Liga;
import junit.framework.TestCase;

/**
 * Description:   <br/>
 * User: roman
 * Date: 18.11.2007, 11:44:18
 */
public class ModelConverterTest extends TestCase {
    public void testConvert() {
        Liga benden =
                ServiceFactory.get(LigaService.class).findLigaByName("Benden");
        ModelConverter converter =
                new ModelConverter(ServiceFactory.get(GruppenService.class));
        OSetting setting = converter.convert(benden);
        assertNotNull(setting);
    }

}
