delete from ligateamwunsch;
delete from ligateamspiel;
delete from ligateam;
delete from spielort;
delete from automatenaufsteller;
delete from ligagruppe;
delete from liga;
