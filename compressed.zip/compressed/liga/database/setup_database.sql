-- setup postgres
-- cd pgsql\bin
-- initdb -D ..\data
-- pg_ctl -D ..\data start

-- psql -d postgres

CREATE ROLE postgres LOGIN
  PASSWORD 'anfang'
  NOSUPERUSER INHERIT CREATEDB NOCREATEROLE;

-- psql -d postgres -U postgres
create database liga encoding 'UTF-8' template template0;

-- psql -d liga -U postgres
@create_postgres.sql;
@insert-data.sql;

insert into db_version (version, since) values ('2.7.4', now());

-- danach Export-Import aller Daten aus einer aktuellen Excel-Datei
