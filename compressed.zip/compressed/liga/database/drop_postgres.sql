/* ---------------------------------------------------------------------- */
/* Script generated with: DeZign for Databases v4.2.0                     */
/* Target DBMS:           PostgreSQL 8                                    */
/* Project file:          liga_postgres.dez                               */
/* Project name:                                                          */
/* Author:                                                                */
/* Script type:           Database drop script                            */
/* Created on:            2008-05-17 16:21                                */
/* ---------------------------------------------------------------------- */


/* ---------------------------------------------------------------------- */
/* Drop foreign key constraints                                           */
/* ---------------------------------------------------------------------- */

ALTER TABLE automatenaufsteller DROP CONSTRAINT liga_automatenaufsteller;

ALTER TABLE ligagruppe DROP CONSTRAINT ligaklasse_ligagruppe;

ALTER TABLE ligagruppe DROP CONSTRAINT liga_ligagruppe;

ALTER TABLE ligateam DROP CONSTRAINT spielort_ligateam;

ALTER TABLE ligateam DROP CONSTRAINT ligaklasse_ligateam;

ALTER TABLE ligateam DROP CONSTRAINT liga_ligateam;

ALTER TABLE spielort DROP CONSTRAINT liga_spielort;

ALTER TABLE spielort DROP CONSTRAINT automatenaufsteller_spielort;

ALTER TABLE ligateamspiel DROP CONSTRAINT ligateam_ligateamspiel;

ALTER TABLE ligateamspiel DROP CONSTRAINT ligagruppe_ligateamspiel;

ALTER TABLE ligateamwunsch DROP CONSTRAINT wunsch_team1;

ALTER TABLE ligateamwunsch DROP CONSTRAINT wunsch_team2;

/* ---------------------------------------------------------------------- */
/* Drop table "automatenaufsteller"                                       */
/* ---------------------------------------------------------------------- */

/* Drop constraints */

ALTER TABLE automatenaufsteller DROP CONSTRAINT PK_automatenaufsteller;

/* Drop table */

DROP TABLE automatenaufsteller;

/* ---------------------------------------------------------------------- */
/* Drop table "liga"                                                      */
/* ---------------------------------------------------------------------- */

/* Drop constraints */

ALTER TABLE liga DROP CONSTRAINT PK_liga;

/* Drop table */

DROP TABLE liga;

/* ---------------------------------------------------------------------- */
/* Drop table "ligagruppe"                                                */
/* ---------------------------------------------------------------------- */

/* Drop constraints */

ALTER TABLE ligagruppe DROP CONSTRAINT PK_ligagruppe;

/* Drop table */

DROP TABLE ligagruppe;

/* ---------------------------------------------------------------------- */
/* Drop table "ligaklasse"                                                */
/* ---------------------------------------------------------------------- */

/* Drop constraints */

ALTER TABLE ligaklasse DROP CONSTRAINT PK_ligaklasse;

/* Drop table */

DROP TABLE ligaklasse;

/* ---------------------------------------------------------------------- */
/* Drop table "ligateam"                                                  */
/* ---------------------------------------------------------------------- */

/* Drop constraints */

ALTER TABLE ligateam DROP CONSTRAINT PK_ligateam;

/* Drop table */

DROP TABLE ligateam;

/* ---------------------------------------------------------------------- */
/* Drop table "spielort"                                                  */
/* ---------------------------------------------------------------------- */

/* Drop constraints */

ALTER TABLE spielort DROP CONSTRAINT PK_spielort;

/* Drop table */

DROP TABLE spielort;

/* ---------------------------------------------------------------------- */
/* Drop table "ligateamspiel"                                             */
/* ---------------------------------------------------------------------- */

/* Drop constraints */

ALTER TABLE ligateamspiel DROP CONSTRAINT PK_ligateamspiel;

/* Drop table */

DROP TABLE ligateamspiel;

/* ---------------------------------------------------------------------- */
/* Drop table "ligateamwunsch"                                            */
/* ---------------------------------------------------------------------- */

/* Drop constraints */

ALTER TABLE ligateamwunsch DROP CONSTRAINT PK_ligateamwunsch;

/* Drop table */

DROP TABLE ligateamwunsch;
