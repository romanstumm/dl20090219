/* ---------------------------------------------------------------------- */
/* Script generated with: DeZign for Databases v4.2.0                     */
/* Target DBMS:           PostgreSQL 8                                    */
/* Project file:          liga_postgres.dez                               */
/* Project name:                                                          */
/* Author:                                                                */
/* Script type:           Database creation script                        */
/* Created on:            2008-05-17 16:21                                */
/* ---------------------------------------------------------------------- */


/* ---------------------------------------------------------------------- */
/* Tables                                                                 */
/* ---------------------------------------------------------------------- */

/* ---------------------------------------------------------------------- */
/* Add table "automatenaufsteller"                                        */
/* ---------------------------------------------------------------------- */

CREATE TABLE automatenaufsteller (
    aufstellerId SERIAL  NOT NULL,
    aufstellerName CHARACTER VARYING(255)  NOT NULL,
    ligaId INTEGER,
    kontaktName CHARACTER VARYING(255),
    email CHARACTER VARYING(255),
    telefon CHARACTER VARYING(40),
    mobil CHARACTER VARYING(40),
    fax CHARACTER VARYING(40),
    plz CHARACTER VARYING(10),
    ort CHARACTER VARYING(255),
    strasse CHARACTER VARYING(255),
    externeId CHARACTER VARYING(5),
    CONSTRAINT PK_automatenaufsteller PRIMARY KEY (aufstellerId)
);

/* ---------------------------------------------------------------------- */
/* Add table "liga"                                                       */
/* ---------------------------------------------------------------------- */

CREATE TABLE liga (
    ligaId SERIAL  NOT NULL,
    ligaName CHARACTER VARYING(255)  NOT NULL,
    CONSTRAINT PK_liga PRIMARY KEY (ligaId)
);

CREATE UNIQUE INDEX ligaName ON liga (ligaName);

/* ---------------------------------------------------------------------- */
/* Add table "ligagruppe"                                                 */
/* ---------------------------------------------------------------------- */

CREATE TABLE ligagruppe (
    gruppenId SERIAL  NOT NULL,
    gruppenNr SMALLINT  NOT NULL,
    klassenId INTEGER  NOT NULL,
    ligaId INTEGER  NOT NULL,
    modifiedTimestamp TIMESTAMP,
    CONSTRAINT PK_ligagruppe PRIMARY KEY (gruppenId)
);

/* ---------------------------------------------------------------------- */
/* Add table "ligaklasse"                                                 */
/* ---------------------------------------------------------------------- */

CREATE TABLE ligaklasse (
    klassenId SERIAL  NOT NULL,
    klassenName CHARACTER VARYING(255)  NOT NULL,
    rang INTEGER  NOT NULL,
    CONSTRAINT PK_ligaklasse PRIMARY KEY (klassenId)
);

/* ---------------------------------------------------------------------- */
/* Add table "ligateam"                                                   */
/* ---------------------------------------------------------------------- */

CREATE TABLE ligateam (
    ligaTeamId SERIAL  NOT NULL,
    teamName CHARACTER VARYING(255)  NOT NULL,
    spielortId INTEGER  NOT NULL,
    klassenId INTEGER  NOT NULL,
    ligaId INTEGER  NOT NULL,
    wochentag INTEGER  NOT NULL,
    spielzeit TIME  NOT NULL,
    externeId CHARACTER VARYING(5),
    CONSTRAINT PK_ligateam PRIMARY KEY (ligaTeamId)
);

/* ---------------------------------------------------------------------- */
/* Add table "spielort"                                                   */
/* ---------------------------------------------------------------------- */

CREATE TABLE spielort (
    spielortId SERIAL  NOT NULL,
    ligaId INTEGER,
    aufstellerId INTEGER,
    spielortName CHARACTER VARYING(255)  NOT NULL,
    automatenAnzahl INTEGER  NOT NULL,
    freierTag INTEGER,
    kontaktName CHARACTER VARYING(255),
    email CHARACTER VARYING(255),
    telefon CHARACTER VARYING(40),
    mobil CHARACTER VARYING(40),
    fax CHARACTER VARYING(40),
    plz CHARACTER VARYING(10),
    ort CHARACTER VARYING(255),
    strasse CHARACTER VARYING(255),
    externeId CHARACTER VARYING(5),
    CONSTRAINT PK_spielort PRIMARY KEY (spielortId)
);

/* ---------------------------------------------------------------------- */
/* Add table "ligateamspiel"                                              */
/* ---------------------------------------------------------------------- */

CREATE TABLE ligateamspiel (
    spielId SERIAL  NOT NULL,
    platzNr SMALLINT  NOT NULL,
    ligaTeamId INTEGER,
    ligaGruppenId INTEGER  NOT NULL,
    fixiert BOOLEAN DEFAULT false  NOT NULL,
    CONSTRAINT PK_ligateamspiel PRIMARY KEY (spielId)
);

COMMENT ON COLUMN ligateamspiel.platzNr IS '1-8';

COMMENT ON COLUMN ligateamspiel.ligaTeamId IS 'wenn kein team (null) = spielfrei';

/* ---------------------------------------------------------------------- */
/* Add table "ligateamwunsch"                                             */
/* ---------------------------------------------------------------------- */

CREATE TABLE ligateamwunsch (
    wunschId SERIAL  NOT NULL,
    team1 INTEGER  NOT NULL,
    team2 INTEGER  NOT NULL,
    wunschArt SMALLINT  NOT NULL,
    CONSTRAINT PK_ligateamwunsch PRIMARY KEY (wunschId)
);

/* ---------------------------------------------------------------------- */
/* Foreign key constraints                                                */
/* ---------------------------------------------------------------------- */

ALTER TABLE automatenaufsteller ADD CONSTRAINT liga_automatenaufsteller 
    FOREIGN KEY (ligaId) REFERENCES liga (ligaId);

ALTER TABLE ligagruppe ADD CONSTRAINT ligaklasse_ligagruppe 
    FOREIGN KEY (klassenId) REFERENCES ligaklasse (klassenId);

ALTER TABLE ligagruppe ADD CONSTRAINT liga_ligagruppe 
    FOREIGN KEY (ligaId) REFERENCES liga (ligaId);

ALTER TABLE ligateam ADD CONSTRAINT spielort_ligateam 
    FOREIGN KEY (spielortId) REFERENCES spielort (spielortId);

ALTER TABLE ligateam ADD CONSTRAINT ligaklasse_ligateam 
    FOREIGN KEY (klassenId) REFERENCES ligaklasse (klassenId);

ALTER TABLE ligateam ADD CONSTRAINT liga_ligateam 
    FOREIGN KEY (ligaId) REFERENCES liga (ligaId);

ALTER TABLE spielort ADD CONSTRAINT liga_spielort 
    FOREIGN KEY (ligaId) REFERENCES liga (ligaId);

ALTER TABLE spielort ADD CONSTRAINT automatenaufsteller_spielort 
    FOREIGN KEY (aufstellerId) REFERENCES automatenaufsteller (aufstellerId);

ALTER TABLE ligateamspiel ADD CONSTRAINT ligateam_ligateamspiel 
    FOREIGN KEY (ligaTeamId) REFERENCES ligateam (ligaTeamId);

ALTER TABLE ligateamspiel ADD CONSTRAINT ligagruppe_ligateamspiel 
    FOREIGN KEY (ligaGruppenId) REFERENCES ligagruppe (gruppenId);

ALTER TABLE ligateamwunsch ADD CONSTRAINT wunsch_team1 
    FOREIGN KEY (team1) REFERENCES ligateam (ligaTeamId);

ALTER TABLE ligateamwunsch ADD CONSTRAINT wunsch_team2 
    FOREIGN KEY (team2) REFERENCES ligateam (ligaTeamId);
