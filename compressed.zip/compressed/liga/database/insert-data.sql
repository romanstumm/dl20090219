insert into ligaklasse(klassenname, rang) values ('BZ', 10);
insert into ligaklasse(klassenname, rang) values ('A', 20);
insert into ligaklasse(klassenname, rang) values ('B', 30);
insert into ligaklasse(klassenname, rang) values ('C', 40);

--- jetzt FileImporter starten
