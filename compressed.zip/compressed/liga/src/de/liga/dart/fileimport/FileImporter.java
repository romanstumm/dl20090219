package de.liga.dart.fileimport;

import de.liga.dart.automatenaufsteller.service.AutomatenaufstellerService;
import de.liga.dart.common.service.ServiceFactory;
import de.liga.dart.gruppen.check.ProgressIndicator;
import de.liga.dart.liga.service.LigaService;
import de.liga.dart.model.Automatenaufsteller;
import de.liga.dart.model.Liga;
import de.liga.dart.model.Spielort;
import de.liga.dart.spielort.service.SpielortService;
import de.liga.util.fileimport.CSVStringTokenizer;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Description: Einfaches Programm, Dient zur Daten�bernahme aus csv Dateien
 * des Altsystems.<br/>
 * User: roman
 * Date: 11.11.2007, 21:44:35
 */
public class FileImporter implements DataExchanger {
    private static final Log log = LogFactory.getLog(FileImporter.class);
    private File importDir;
    private boolean allMode;
    private boolean success;

    public FileImporter() {
        // do nothing
    }

    public FileImporter(File importDir) {
        this.importDir = importDir;
    }

    public static void main(String[] args) throws Exception {
        new FileImporter().start();
    }

    public boolean start() {
        allMode = true;
        success = true;
        ServiceFactory.runAsTransaction(new Runnable() {
            public void run() {
                String[] ligen = {"Benden", "Eifel", "Kgl", "L�wen", "Rhl-WW",
                        "Siegerland", "Ruhrpott"};
                for (String liga : ligen) {
                    try {
                        doLiga(liga);
                    } catch (IOException e) {
                        log.error(e.getMessage(), e);
                        success = false;
                    }
                }
            }
        });
        log.info("Fertig!");
        return success;
    }

    public boolean start(final String liga) {
        allMode = false;
        success = true;
        ServiceFactory.runAsTransaction(new Runnable() {
            public void run() {
                try {
                    doLiga(liga);
                } catch (IOException e) {
                    log.error(e.getMessage(), e);
                    success = false;
                }
            }
        });
        return success;
    }

    public void setProgressIndicator(ProgressIndicator indicator) {
        // do nothing
    }

    private void doLiga(String liganame) throws IOException {
        log.info("------------ " + liganame + " -----------");
        Liga liga = doLigaItself(liganame);
        doLigaAufsteller(liganame, liga);
        doSpielorte(liganame, liga);
    }

    public File getImportFile(String liga, String file) {
        if (importDir == null) {
            return new File("docs/Gaststaettendateien/" + liga, file);
        } else {
            if (allMode) {
                return new File(importDir + "/" + liga, file);
            } else {
                return new File(importDir, file);
            }
        }
    }

    private static String[] aufstellerFields = {"key", "aufstellerName", "kontaktName",
            "strasse", "plz", "ort", "telefon", "fax"};

    Map<String, Long> aufstellerKeyMap = new HashMap();
    Map<String, Automatenaufsteller> aufstellerNameMap = new HashMap();

    private void doLigaAufsteller(String filedir, Liga liga) throws IOException {
        aufstellerKeyMap.clear();
        File file = getImportFile(filedir, "LITAUF.csv");
        BufferedReader reader = new BufferedReader(new FileReader(file));
        try {
            String line = reader.readLine();
            while (line != null) {
                log.info("importing " + line);
                CSVStringTokenizer tokenizer = new CSVStringTokenizer(line, ";");
                int i = 0;
                Map<String, String> data = new HashMap();
                while (tokenizer.hasMoreTokens()) {
                    data.put(aufstellerFields[i++], tokenizer.nextToken());
                }
                Automatenaufsteller aufsteller = new Automatenaufsteller();
                aufsteller.setLiga(liga);
                aufsteller.setAufstellerName(data.get("aufstellerName"));
                if (aufstellerNameMap.containsKey(aufsteller.getAufstellerName())) {
                    aufsteller = aufstellerNameMap.get(aufsteller.getAufstellerName());
                    aufstellerKeyMap.put(data.get("key"), aufsteller.getAufstellerId());
                    aufsteller.setLiga(null);
                    line = reader.readLine();
                    continue;
                } else {
                    aufstellerNameMap.put(aufsteller.getAufstellerName(), aufsteller);
                }
                aufsteller.setKontaktName(data.get("kontaktName"));
                aufsteller.setStrasse(data.get("strasse"));
                aufsteller.setPlz(data.get("plz"));
                aufsteller.setOrt(data.get("ort"));
                aufsteller.setTelefon(data.get("telefon"));
                aufsteller.setFax(data.get("fax"));
                ServiceFactory.get(AutomatenaufstellerService.class)
                        .saveAutomatenaufsteller(aufsteller);
                aufstellerKeyMap
                        .put(data.get("key"), aufsteller.getAufstellerId());
                line = reader.readLine();
            }
        } finally {
            reader.close();
        }
    }

    private Liga doLigaItself(String liganame) {
        Liga liga = ServiceFactory.get(LigaService.class).findLigaByName(liganame);
        if (liga == null) {
            liga = new Liga();
            liga.setLigaName(liganame);
            ServiceFactory.get(LigaService.class).saveLiga(liga);
        }
        return liga;
    }

    private static String[] spielorteFields = {"key", "null", "null", "null",
            "spielortName", "spielortTyp", "strasse", "plz", "ort", "telefon", "fax",
            "freierTag", "aufstellerNr"};

    private void doSpielorte(String filedir, Liga liga) throws IOException {
        File file = getImportFile(filedir, "LITLOK.csv");
        BufferedReader reader = new BufferedReader(new FileReader(file));
        try {
            String line = reader.readLine();
            while (line != null) {
                log.info("importing " + line);
                CSVStringTokenizer tokenizer = new CSVStringTokenizer(line, ";");
                int i = 0;
                Map<String, String> data = new HashMap();
                while (tokenizer.hasMoreTokens()) {
                    data.put(spielorteFields[i++], tokenizer.nextToken());
                }
                Spielort spielort = new Spielort();
                spielort.setLiga(liga);
                spielort.setSpielortName(data.get("spielortName"));
                spielort.setStrasse(data.get("strasse"));
                spielort.setPlz(data.get("plz"));
                spielort.setOrt(data.get("ort"));
                spielort.setTelefon(data.get("telefon"));
                spielort.setFax(data.get("fax"));
                spielort.setFreierTagName(data.get("freierTag"));
                Long aufstellerId = aufstellerKeyMap.get(data.get("aufstellerNr"));
                if (aufstellerId != null) {
                    Automatenaufsteller aufsteller = ServiceFactory
                            .get(AutomatenaufstellerService.class)
                            .findAutomatenaufstellerById(aufstellerId);
                    spielort.setAutomatenaufsteller(aufsteller);
                }
                ServiceFactory.get(SpielortService.class).saveSpielort(spielort);
                line = reader.readLine();
            }
        } finally {
            reader.close();
        }
    }
}
