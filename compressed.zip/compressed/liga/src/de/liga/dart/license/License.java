package de.liga.dart.license;

public interface License {
    boolean isValid(String application, String version, String customer);

    String getInfoMessage();

    void license(Licensable object);
}
