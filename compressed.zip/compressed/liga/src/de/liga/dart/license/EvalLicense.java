package de.liga.dart.license;

import de.liga.dart.Application;

import java.util.Calendar;
import java.util.Date;

public class EvalLicense implements License {

    private final Date validUntil = createDate(2008, 5, 30);

    public boolean isValid(String application, String version, String customer) {
        return Application.APPLICATION_NAME.equals(application) &&
                Application.APPLICATION_VERSION.equals(version) &&
                new Date(System.currentTimeMillis()).before(validUntil);
    }

    public String getInfoMessage() {
        return getClass()
                .getSimpleName() + " for " + Application.APPLICATION_NAME + " " +
                Application.APPLICATION_VERSION + " (valid until " + validUntil +
                ")";
    }

    public void license(Licensable object) {
        object.useLicense(this);
    }

    private static Date createDate(int year, int month, int day) {
        Calendar gc = Calendar.getInstance();
        gc.clear();
        gc.set(year, month - 1, day);

        return new Date(gc.getTimeInMillis());
    }
}
