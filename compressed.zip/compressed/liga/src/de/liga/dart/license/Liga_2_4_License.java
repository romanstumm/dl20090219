package de.liga.dart.license;

public class Liga_2_4_License implements License {
    public boolean isValid(String application, String version,
                           String customer) {
        return "Ligaverwaltung".equals(application) &&
                version.startsWith("2.4") &&
                "TWL".equals(customer);
    }

    public String getInfoMessage() {
        return "Ligaverwaltung 2.4 Lizensiert f�r TWL, Horst Lichtenth�ler";
    }

    public void license(Licensable object) {
        object.useLicense(this);
    }
}
