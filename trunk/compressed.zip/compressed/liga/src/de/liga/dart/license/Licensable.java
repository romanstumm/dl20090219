package de.liga.dart.license;

/**
 * Description:   <br/>
 * User: roman
 * Date: 05.01.2008, 11:45:48
 */
public interface Licensable {
    void useLicense(Object license);
}
