package de.liga.dart.license;

public class Liga_2_5_License implements License {
    public boolean isValid(String application, String version,
                           String customer) {
        return "Ligaverwaltung".equals(application) &&
                version.startsWith("2.5") &&
                "TWL".equals(customer);
    }

    public String getInfoMessage() {
        return "Ligaverwaltung 2.5 Lizensiert f�r TWL, Horst Lichtenth�ler";
    }

    public void license(Licensable object) {
        object.useLicense(this);
    }
}
