package de.liga.dart.gruppen.service;

import de.liga.dart.common.service.ServiceFactory;
import de.liga.dart.liga.service.LigaService;
import de.liga.dart.ligaklasse.service.LigaklasseService;
import de.liga.dart.ligateam.service.LigateamService;
import de.liga.dart.model.Liga;
import de.liga.dart.model.Ligagruppe;
import de.liga.dart.model.Ligaklasse;
import de.liga.dart.model.Ligateam;
import junit.framework.TestCase;

import java.util.List;

/**
 * Description:   <br/>
 * User: roman
 * Date: 02.11.2007, 15:02:51
 */
public class GruppenServiceTest extends TestCase {

    public GruppenServiceTest(String string) {
        super(string);
    }

    public void testDeleteGruppe() {
        Ligagruppe gruppe = new Ligagruppe();
        gruppe.setLiga(ServiceFactory.get(LigaService.class).findLigaByName("Benden"));
        gruppe.setLigaklasse(ServiceFactory.get(LigaklasseService.class).findLigaklasseByName("A"));

        GruppenService service = ServiceFactory.get(GruppenService.class);
        service.saveLigagruppe(gruppe);
        assertTrue(gruppe.getGruppenNr() > 0);
        assertTrue(gruppe.getGruppenId() > 0);
        List<Ligateam> teams =
                ServiceFactory.get(LigateamService.class).findAllTeams();
        service.setTeamIntoGruppe(gruppe, teams.get(0), 1, false);
        service.setTeamIntoGruppe(gruppe, teams.get(1), 2, false);
        service.setTeamIntoGruppe(gruppe, teams.get(2), 3, false);
        service.deleteLigagruppe(gruppe);
    }

    /**
     * den "test" kann man mehrmals durchlaufen lassen.
     * - er setzt zuerst alle benden teams in Liga A.
     * - wenn alle Teams gesetzt sind, setzt er das 1. team immer einen gruppenplatz h�her.
     * - wenn es auf platz 8 steht, setzt er den platz auf spielfrei
     * - dann geht es mit dem platzsetzen von vorne los, wobei die spielfrei position
     *   irgendwann wieder mit dem team besetzt wird.  
     */
    public void testFindUnassignedTeams() {
        doAsTransaction();
        doAsTransaction();
        doAsTransaction();
        doAsTransaction();
        doAsTransaction();
        doAsTransaction();
        doAsTransaction();
        doAsTransaction();
        doAsTransaction();
    }

    private void doAsTransaction() {
        ServiceFactory.runAsTransaction(new Runnable() {

            public void run() {
                GruppenService service =
                        ServiceFactory.get(GruppenService.class);
                Liga benden = ServiceFactory.get(LigaService.class)
                        .findLigaByName("Benden");
                Ligaklasse a = ServiceFactory.get(LigaklasseService.class)
                        .findLigaklasseByName("A");
                assertNotNull(benden);
                assertNotNull(a);
                List<Ligateam> teams = service.findUnassignedTeams(benden, a, null, null);
                if (!teams.isEmpty()) {
                    List<Ligagruppe> gruppen = service.findGruppen(benden, a);
                    Ligagruppe gruppe;
                    if (gruppen.isEmpty()) {
                        gruppe = new Ligagruppe();
                        gruppe.setLiga(benden);
                        gruppe.setLigaklasse(a);
                        // gruppennummer wird automatisch vergeben!
                        service.saveLigagruppe(gruppe);
                    } else {
                        gruppe = gruppen.get(0);
                    }

                    Ligateam team = teams.get(0);

                    service.setTeamIntoGruppe(gruppe, team, 1, false);

                } else {
                    teams = ServiceFactory.get(LigateamService.class)
                            .findAllTeamsInLiga(benden);
                    Ligateam team = teams.get(0);
                    List<Ligagruppe> gruppen = service.findGruppen(benden, a);
                    Ligagruppe gruppe = gruppen.get(0);
                    if (team.getLigateamspiel().getPlatzNr() < 8) {
                        service.setTeamIntoGruppe(gruppe, team,
                                team.getLigateamspiel().getPlatzNr() + 1, false);
                    } else {
                        service.setSpielfreiIntoGruppe(gruppe, 8, false);
                    }
                }
            }
        });
    }
}
