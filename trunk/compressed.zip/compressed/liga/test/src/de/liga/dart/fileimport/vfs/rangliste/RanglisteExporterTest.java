package de.liga.dart.fileimport.vfs.rangliste;

import junit.framework.TestCase;
import de.liga.dart.model.Ligagruppe;
import de.liga.dart.model.Liga;
import de.liga.dart.model.Ligaklasse;
import de.liga.dart.fileimport.vfs.DbfImporter;
import de.liga.dart.fileimport.vfs.DbfImportErgebnis;

import java.io.IOException;
import java.io.File;
import java.util.Calendar;
import java.util.List;
import java.util.ArrayList;
import java.sql.*;

import freemarker.template.TemplateException;
import org.hibernate.repackage.cglib.asm.attrs.Annotation;

/**
 * Description:   <br/>
 * User: roman
 * Date: 03.05.2009, 16:57:06
 */
public class RanglisteExporterTest extends TestCase {

    public RanglisteExporterTest() {
    }

    public RanglisteExporterTest(String string) {
        super(string);
    }

    public void testOdbcJdbcBridge() throws Exception {
        Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
//        java.sql.DriverManager.setLogStream(java.lang.System.out);
        Connection connection = DriverManager.getConnection("jdbc:odbc:VFS-LOEWEN");
        PreparedStatement stmt = connection.prepareStatement("SELECT t.SAI_NR, l.LIG_NAME, l.LIG_KLASSE, t.SAI_NR, t.LIG_NR, t.TEA_NR, " +
                        "t.TEA_NAME, t.LOK_NR, t.TEA_SPIELT, " +
                        "t.TEA_UHRZEI, t.TEA_STATUS FROM LITTEA t, " +
                        "LITLIG l " +
                        "WHERE t.LIG_NR=l.LIG_NR AND (t.TEA_STATUS IS NULL OR t.TEA_STATUS<>'D')" +
                " AND t.LIG_NR=? AND YEAR(t.SAI_NR)=? AND MONTH(t.SAI_NR)=?"); // AND MONTH(t.SAI_NR) = ?");
        stmt.setObject(1, 2);
        stmt.setInt(2, 2009);
        stmt.setInt(3, 1);
        ResultSet rs = stmt.executeQuery();
        int rowc = 0;
        while (rs.next()) {
            System.out.println((rowc++) + "=> " + rs.getObject(1) + ", "
                    + rs.getObject(2) + ", " +
                    rs.getObject(5) + ", " + rs.getObject(4)
            +", " + rs.getObject(3)+ ", " + rs.getObject(6));
        }
        rs.close();
        stmt.close();
        connection.close();
        System.out.println("Fertig und gut!");
    }

    public void testVfsConfig() {
        VfsConfig vfsConfig;
        assertNotNull(vfsConfig = RanglisteExporter.getVfsConfig());
        System.out.println(vfsConfig);
    }

    public void testPlainNames() {
        VfsTeam team = new VfsTeam();
        team.setVfsLiga(new VfsLiga());
        team.getVfsLiga().setName("C16 Rheinland-Westerwald");
        assertEquals("16", team.getPlainGruppenNr());
        assertEquals("Rheinland-Westerwald", team.getPlainLigaName());
        team.getVfsLiga().setName("B2 Benden-D�sseldorf");
        assertEquals("2", team.getPlainGruppenNr());
        assertEquals("Benden-D�sseldorf", team.getPlainLigaName());
        team.getVfsLiga().setName("A Benden-D�sseldorf");
        assertEquals("", team.getPlainGruppenNr());
        assertEquals("Benden-D�sseldorf", team.getPlainLigaName());
        team.getVfsLiga().setName("Bezirksliga 1 Eifel");
        assertEquals("1", team.getPlainGruppenNr());
        assertEquals("Eifel", team.getPlainLigaName());
        team.getVfsLiga().setName("Bezirksliga Benden");
        assertEquals("", team.getPlainGruppenNr());
        assertEquals("Benden", team.getPlainLigaName());
    }

    public void testCompile() throws IOException, TemplateException {
        RanglisteExporter exporter = new RanglisteExporter(null);
        VfsTeam team = new VfsTeam();
        VfsLiga liga = new VfsLiga();
        liga.setName("Bezirksliga 1 L�wen");
        liga.setKlasse("BZ");
        team.setVfsLiga(liga);
        exporter.compile(team);
        assertEquals("1", team.getPlainGruppenNr());
        assertEquals("L�wen", team.getPlainLigaName());
        assertEquals("Bezirksliga 1 L�wen", team.getKlasse());
        assertEquals("L�wen-Bezirksliga 1", team.getLiganame());
        assertEquals("Bezirksliga-Meister", team.getLigameister());

        // teste templates mit klasse "B"
        liga.setName("B2 L�wen");
        liga.setKlasse("B");
        assertEquals("2", team.getPlainGruppenNr());
        assertEquals("L�wen", team.getPlainLigaName());
        exporter.compile(team);
        assertEquals("B2", team.getKlasse());
        assertEquals("L�wen", team.getLiganame());
        assertEquals("B Liga-Meister", team.getLigameister());
    }

    public void testTomorrow() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, 1);
        java.sql.Date tomorrow = new java.sql.Date(cal.getTimeInMillis());
        assertNotNull(tomorrow);
    }

    public void testExportErgebnis() throws Exception {
        DbfImporter.putLigaSync("L�wen", "D:/DRLIGA/LOEWEN/liga");
        RanglisteExporter exporter = new RanglisteExporter(new File("testrang.xls"));
        exporter.setProgressIndicator(new PrintIndicator());
        exporter.start("L�wen");
    }

}
