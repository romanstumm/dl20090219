package de.liga.util.dbf;

import junit.framework.TestCase;

import java.nio.charset.Charset;
import java.sql.*;
import java.util.Map;
import java.util.Properties;
import java.util.SortedMap;

/**
 * Description:   <br/>
 * User: roman
 * Date: 15.03.2008, 17:28:31
 */
public class DbfReaderTest extends TestCase {
    public DbfReaderTest(String string) {
        super(string);
    }

    public void testIt() {
        assertEquals(1, Integer.parseInt("1.0"));
    }

    public void testCharsets() {
        SortedMap<String, Charset> m = Charset.availableCharsets();
        for (Map.Entry<String, Charset> e : m.entrySet()) {
            System.out.println(e.getKey() + " => " + e.getValue());
        }
    }

    public void testFindCharset() throws Exception {

        Class.forName("jstels.jdbc.dbf.DBFDriver");
        SortedMap<String, Charset> m = Charset.availableCharsets();
        for (Map.Entry<String, Charset> e : m.entrySet()) {
            try {
                Properties props = new java.util.Properties();
                props.setProperty("caching", "false");
                props.put("charset", e.getKey());

                Connection conn =
                        DriverManager
                                .getConnection(
                                        "jdbc:jstels:dbf:docs/Gaststaettendateien/dbf/rhl-ww",
                                        props);
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(
                        "SELECT AUF_NR, AUF_NAME, AUF_ZUSATZ, AUF_STRASS, AUF_PLZ, AUF_ORT, AUF_TEL, AUF_FAX FROM \"LITAUF.DBF\" where AUF_NR = 6");
                print2(rs, e.getKey());
//        rs = stmt.executeQuery(
//                "SELECT LOK_NR, LOK_NAME, LOK_ZUSATZ, LOK_STRASS, LOK_PLZ, LOK_ORT, LOK_TEL, LOK_FAX, LOK_RUHETA, AUF_NR FROM \"LITLOK.DBF\"");
//        print(rs);
                stmt.close();
                conn.close();
            } catch (Exception ex) {
            }
        }
    }

    public void testPrintData() throws Exception {

        Class.forName("jstels.jdbc.dbf.DBFDriver");
        Properties props = new java.util.Properties();
        props.setProperty("caching", "false");
        props.put("charset", "IBM850");

        Connection conn =
                DriverManager
                        .getConnection("jdbc:jstels:dbf:D:/Develop/horst/liga/docs/Gaststaettendateien/dbf/benden",
                                props);
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(
                "SELECT AUF_NR, AUF_NAME, AUF_ZUSATZ, AUF_STRASS, AUF_PLZ, AUF_ORT, AUF_TEL, AUF_FAX FROM \"LITAUF.DBF\" where AUF_NR = 6");
        print(rs);
        rs = stmt.executeQuery(
                "SELECT LOK_NR, LOK_NAME, LOK_ZUSATZ, LOK_STRASS, LOK_PLZ, LOK_ORT, LOK_TEL, LOK_FAX, LOK_RUHETA, AUF_NR FROM \"LITLOK.DBF\"");
        print(rs);
        stmt.close();
        conn.close();
    }

    private void print(ResultSet rs) throws SQLException {
        ResultSetMetaData rsm = rs.getMetaData();
        int cc = rsm.getColumnCount();
        /*
        for(int ci = 1;ci<=cc;ci++) {
            System.out.print(rsm.getColumnName(ci) + ", ");
        }
        System.out.println("~~~~~~~~~~~~~~");*/
        while (rs.next()) {
            for (int i = 1; i <= cc; i++) {
                System.out.print(rs.getString(i) + ",");
            }
            System.out.println();
        }
        System.out.println("------------");
    }

    private void print2(ResultSet rs, String charset) throws SQLException {
        /*
        for(int ci = 1;ci<=cc;ci++) {
            System.out.print(rsm.getColumnName(ci) + ", ");
        }
        System.out.println("~~~~~~~~~~~~~~");*/
        if (!rs.next()) return;
        String s = rs.getString("AUF_ORT");
        if (s != null && s.equals("K�lbingen")) {
            System.out.println(charset + " ===> " + s);
        }
    }
}

