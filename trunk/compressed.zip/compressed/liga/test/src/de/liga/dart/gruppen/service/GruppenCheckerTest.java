package de.liga.dart.gruppen.service;

import de.liga.dart.common.service.ServiceFactory;
import de.liga.dart.gruppen.CheckResult;
import de.liga.dart.liga.service.LigaService;
import de.liga.dart.model.Liga;
import junit.framework.TestCase;

/**
 * Description:   <br/>
 * User: roman
 * Date: 03.11.2007, 17:19:51
 */
public class GruppenCheckerTest extends TestCase {

    public GruppenCheckerTest(String string) {
        super(string);
    }

    public void testCheck() {
        Liga benden =
                ServiceFactory.get(LigaService.class).findLigaByName("Benden");
        GruppenService service = ServiceFactory.get(GruppenService.class);
        CheckResult result = service.checkGruppen(benden);
        result.print(System.out, 0);
    }
}
